#!/bin/bash
echo "Starting"
java -Xmx1G -jar nortantis_map_generator.jar
