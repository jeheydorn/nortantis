#!/bin/bash
echo "Starting"
java -XX:MaxRAMPercentage=50.0 -Dfile.encoding=UTF-8 -jar nortantis_map_generator.jar
