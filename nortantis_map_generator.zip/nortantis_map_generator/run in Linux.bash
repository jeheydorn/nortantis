#!/bin/bash
echo "Starting"
java -Xmx2G -jar nortantis_map_generator.jar
