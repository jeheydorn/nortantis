#!/bin/bash
echo "Starting"
java -jar nortantis_map_generator.jar
