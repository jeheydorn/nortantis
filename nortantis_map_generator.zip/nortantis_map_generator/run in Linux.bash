#!/bin/bash
echo "Starting"
java -XX:MaxRAMPercentage=50.0 -jar nortantis_map_generator.jar
